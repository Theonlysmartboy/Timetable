<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.9";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="fb-post" data-href="https://web.facebook.com/lepski92/posts/1507845419236788" data-width="500" data-show-text="true"><blockquote cite="https://www.facebook.com/lepski92/posts/1507845419236788" class="fb-xfbml-parse-ignore"><p>Luos don&#x2019;t pee, they engage their urethra in an action of depositing ammonia through titration yawa!</p>Posted by <a href="https://www.facebook.com/lepski92">Tom Lepski</a> on&nbsp;<a href="https://www.facebook.com/lepski92/posts/1507845419236788">Tuesday, July 4, 2017</a></blockquote></div>